package com.example.myjava;

import androidx.appcompat.app.AppCompatActivity;

import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.TextView;

public class MainActivity extends AppCompatActivity {

    private EditText a, h, d1, d2;
    private Button sah;
    private Button sd;
    private TextView resText;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        a = findViewById(R.id.a);
        h = findViewById(R.id.h);
        d1 = findViewById(R.id.d1);
        d2 = findViewById(R.id.d2);
        sah = findViewById(R.id.sah);
        sd = findViewById(R.id.sd);
        resText = findViewById(R.id.resText);

        sah.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                float pa = Float.parseFloat(a.getText().toString());
                float ph = Float.parseFloat(h.getText().toString());
                float res = pa*ph;
                resText.setText(String.valueOf(res));
            }
        });
        sd.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                float pd1 = Float.parseFloat(d1.getText().toString());
                float pd2 = Float.parseFloat(d2.getText().toString());
                float res = (pd1*pd2)/2;
                resText.setText(String.valueOf(res));
            }
        });
    }
}